=== Finlyzer — FX Loss & Margin Insights for WooCommerce ===
Contributors: sl3nd3r, raygens, finlyzer
Tags: woocommerce, currency, fx, payments, conversion fees
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.1
Requires Plugins: woocommerce
WC requires at least: 8.0
WC tested up to: 11.1
Stable tag: 1.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Track hidden payment gateway conversion fees, currency loss, and protect international WooCommerce profit margins. 100% Free.

== Description ==

Finlyzer gives WooCommerce merchants clear, honest visibility into how much revenue is lost to foreign exchange fees and payment processor markups on international sales. It is **100% Free** with no hidden fees, no subscriptions, and no credit card required.

### 🔒 100% Local by Default — Zero Surveillance Telemetry

Merchants trust Finlyzer because of its privacy architecture:
* **Runs 100% Locally on Your Store Database by Default**: All currency loss math, gateway fee spread analysis, and multi-currency ledgers are calculated entirely on your own server. Zero external network calls are made out-of-the-box.
* **No Sensitive Information Needed**: Finlyzer **never** requests, accesses, stores, logs, or transmits sensitive customer or financial data.
* **Zero Personally Identifiable Information (PII)**: Customer names, email addresses, phone numbers, billing/shipping physical addresses, IP addresses, credit card numbers, and individual order IDs are **never collected, saved, or sent anywhere**.
* **Zero Checkout Impact**: Runs purely in the WordPress admin dashboard for completed orders. Your checkout flow, storefront speed, and buyer experience remain 100% untouched.

### Why Every International WooCommerce Store Needs Finlyzer

When international shoppers purchase from your store in foreign currencies (EUR, GBP, CAD, AUD, JPY, etc.), payment processors like PayPal, Stripe, Klarna, WooPayments, Mollie, and Adyen convert those funds into your payout currency. 

Instead of using true interbank market exchange rates, payment gateways charge hidden conversion spreads—typically pocketing **1.5% to 4.2% or more** on every cross-border order. On top of gateway spreads, foreign exchange rate fluctuations during settlement create additional currency loss.

Finlyzer inspects your store sales data and reveals the exact numbers:
* **Total Currency Loss**: View exact currency loss across the last 30, 60, or 90 days.
* **Effective Fee Rate**: Reveal true conversion spreads per processor (Stripe, PayPal, Klarna, etc.).
* **Loss Distribution by Currency**: Visual breakdown showing which currencies erode margins most.
* **Annual Run-Rate Exposure**: Projected yearly loss if gateway markup is left unaddressed.
* **AI Sentinel Insights**: Real-time risk audit powered by Google Gemini Flash AI providing prioritized, actionable recommendations to protect merchant profits.

### Key Features for WooCommerce Merchants

* **Payment Gateway Fee Comparison**: Compares cross-border transaction volume and conversion fee impact across Stripe, PayPal, Klarna, WooPayments, and more.
* **Multi-Currency Revenue Ledger**: Detailed breakdown of transaction volume, fee share, and currency loss per foreign currency.
* **Products Breakdown**: Line-by-line attribution of international revenue and conversion fees per product, with fast processor filtering.
* **Exchange Rate Movement & Market Timing**: Directly queries European Central Bank reference exchange rates via the public Frankfurter API (https://api.frankfurter.dev) using WordPress HTTP API (`wp_remote_get`) to evaluate settlement timing loss between order placement and processor payout.
* **High-Performance Order Storage (HPOS)**: Built-in native support for WooCommerce custom order tables (`wc_orders`) and traditional post meta.
* **Lightweight & Fast**: Pure server-to-server analytics engine with cached responses and asynchronous telemetry.
* **100% Free**: Full access to all financial analytics with zero paywalls.

### Developer & Maintainer

Finlyzer is developed and maintained by [Ebrahim Razmahang](https://www.linkedin.com/in/ebrahimrazmahang) (GitHub: [sl3nd3r1](https://github.com/sl3nd3r1)).

== External Services ==

Finlyzer operates 100% locally by default. Optionally, administrators can opt into external services for automated AI risk analysis and market rate evaluation:

* **Finlyzer Cloudflare Worker API & Google Gemini Flash AI (Optional — 100% Opt-In Only)**: Provides automated financial margin risk audits and recommendations powered by Google Gemini via a secure Cloudflare Worker proxy.
  - Opt-in Status: **Disabled / OFF by default**. Requires explicit administrator opt-in in the Finlyzer settings dialog before any network request is dispatched.
  - Service: https://ai.google.dev / https://finlyzer-worker-prod.ebi1055lol.workers.dev
  - Cloudflare Terms of Service: https://www.cloudflare.com/terms/
  - Cloudflare Privacy Policy: https://www.cloudflare.com/privacypolicy/
  - Google Gemini Terms of Service: https://ai.google.dev/terms
  - Google Privacy Policy: https://policies.google.com/privacy
  - Data Sent (only upon explicit opt-in): Strictly anonymized, store-level aggregate metrics (store currency ISO code, total transaction volume, aggregate conversion fee estimates, currency breakdown, and order counts).
  - **Zero Personally Identifiable Information (PII)**: Customer names, email addresses, phone numbers, billing/shipping physical addresses, IP addresses, payment card credentials, and individual order IDs are never collected, logged, or transmitted.

* **Global Market Reference Rates / Frankfurter API (European Central Bank Reference Data)**: Used to evaluate payment processor conversion fee markups and market timing exchange rate shifts.
  - Service: https://frankfurter.dev / https://api.frankfurter.dev (data published by European Central Bank: https://www.ecb.europa.eu)
  - Terms of Service: https://frankfurter.dev
  - Privacy Policy: https://frankfurter.dev
  - How It Operates: The plugin uses WordPress HTTP API (`wp_remote_get`) from your WordPress server to fetch reference exchange rates for the store's active transaction currencies.
  - Local Transient Caching: Rates are locally cached in WordPress Transients for 12 hours (matching ECB daily 16:00 CET fixings) to minimize remote requests and maintain fast dashboard load times.
  - Resilient Fallback: If the API is unreachable, the plugin gracefully falls back to an internal reference matrix so dashboard operations remain uninterrupted.
  - Data Sent: Currency ISO codes (e.g., "EUR", "USD") via URL parameters. No store details, customer records, or financial transaction identifiers are ever sent.

== Third-Party Libraries & Source Code ==

* **HTMX** (v2.0.3): Used in the WordPress admin dashboard for reactive UI swaps and fragment serving without full-page reloads.
  - Source Code: https://github.com/bigskysoftware/htmx
  - Unminified Distribution: assets/js/vendor/htmx.js (also accessible at https://github.com/bigskysoftware/htmx/releases/tag/v2.0.3)
  - License: BSD-2-Clause (GPL-compatible) https://github.com/bigskysoftware/htmx/blob/master/LICENSE

== Installation ==

### WordPress Admin Upload
1. Download the `finlyzer.zip` archive.
2. In your WordPress admin dashboard, navigate to **Plugins > Add New > Upload Plugin**.
3. Choose `finlyzer.zip` and click **Install Now**.
4. Click **Activate Plugin**.
5. Go to the **Finlyzer** menu in your WordPress sidebar to view your currency audit.

### System Requirements
* WordPress 6.4 or higher
* WooCommerce 8.0 or higher (HPOS supported)
* PHP 8.1 or higher (PHP 8.2 & 8.3 fully supported)
* MySQL 5.7+ or MariaDB 10.4+

== Frequently Asked Questions ==

= Is Finlyzer really free? =
Yes, Finlyzer is 100% free with no hidden charges, trial periods, or credit card requirements.

= Does Finlyzer access sensitive customer data? =
No, never. Finlyzer adheres to strict privacy-by-design standards. The plugin never requests, accesses, stores, or transmits sensitive customer information. There is Zero Personally Identifiable Information (PII) collected or sent. Customer names, emails, addresses, payment card numbers, and individual order numbers are never touched.

= Will Finlyzer slow down customer checkout? =
Never. Finlyzer operates only in the WordPress admin dashboard for completed orders. It does not execute scripts or styles on your customer-facing checkout page.

= Does Finlyzer require an API key to display conversion fees? =
No. Finlyzer reads your existing WooCommerce order history and computes gateway conversion spreads without requiring any external account setup.

= Which payment processors are analyzed? =
Finlyzer recognizes conversion spread models for PayPal, Stripe, Klarna, WooPayments, Adyen, Mollie, Square, Direct Wire/BACS, Cash on Delivery, and standard credit card gateways.

== Changelog ==

= 1.2.0 =
* Feature: Decoupled resilient dashboard rendering engine with independent fragment resolution (`Promise.allSettled`).
* Resilience: Self-healing automated site pairing lifecycle with HMAC token re-synchronization on authorization expiration.
* Reliability: Fail-open fallback to local calculation engine ensuring zero dashboard disruption during remote network interruptions.
* Security: Comprehensive nonce verification supporting both request headers and query parameters for cross-environment compatibility.
* UI: Refined Cloud Sentinel interface clean naming standards.

= 1.1.0 =
* Feature: Direct European Central Bank (ECB) exchange rate integration via Frankfurter API (https://api.frankfurter.dev) using WordPress HTTP API (`wp_remote_get`).
* Feature: Settlement timing volatility calculation engine (`FXLI_Rate_Service`) to track currency shifts between order placement and processor payout.
* Performance: Multi-tier rate caching with 12-hour WordPress Transients and request-scoped memory cache.
* Resilience: Built-in offline ECB reference matrix fallback for uninterrupted performance during network outages.

= 1.0.0 =
* Initial release: complete payment gateway conversion fee auditing, FX currency loss calculations, multi-currency ledger, HPOS compatibility, zero-PII privacy architecture, and AI-driven profit margin recommendations.
