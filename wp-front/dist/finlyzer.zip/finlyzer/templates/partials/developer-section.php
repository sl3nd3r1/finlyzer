<?php declare(strict_types=1); if (!defined("ABSPATH")) exit; // Developer section is omitted from production builds.
