<?php
declare(strict_types=1);

// prevent direct script execution outside WordPress context
if (!defined('ABSPATH')) {
	exit;
}

/**
 * Environment configuration and security boundary manager for Finlyzer.
 * Coordinates development vs production profiles, baked build-time constants,
 * runtime overrides, SSRF URL defenses, and developer diagnostic tooling.
 */
final class FXLI_Env {

	public const ENV_DEVELOPMENT = 'development';
	public const ENV_PRODUCTION = 'production';

	private static ?array $parsed_env_cache = null;

	// check if the current server host represents a local development environment (e.g. XAMPP, WAMP, LocalWP, Docker, CLI)
	public static function is_local_host(): bool {
		// check if running in PHP CLI or built-in web server
		if (php_sapi_name() === 'cli' || php_sapi_name() === 'cli-server') {
			return true;
		}

		// inspect server host variables
		$raw_host = '';
		if (isset($_SERVER['HTTP_HOST'])) {
			$raw_host = sanitize_text_field(wp_unslash($_SERVER['HTTP_HOST']));
		} elseif (isset($_SERVER['SERVER_NAME'])) {
			$raw_host = sanitize_text_field(wp_unslash($_SERVER['SERVER_NAME']));
		}
		$host = $raw_host;
		if ($host === '' && function_exists('home_url')) {
			$parsed = wp_parse_url(home_url(), PHP_URL_HOST);
			$host = is_string($parsed) ? $parsed : '';
		}

		if ($host === '') {
			return false;
		}

		// clean host from port and IPv6 brackets
		$clean = strtolower(trim($host));
		if (str_starts_with($clean, '[')) {
			$closing = strpos($clean, ']');
			if ($closing !== false) {
				$clean = substr($clean, 1, $closing - 1);
			}
		} elseif (substr_count($clean, ':') === 1) {
			$clean = explode(':', $clean)[0];
		}

		// check standard loopback addresses (IPv4 & IPv6)
		if ($clean === 'localhost' || $clean === '127.0.0.1' || $clean === '::1') {
			return true;
		}

		// check standard local development domain suffixes
		if (str_ends_with($clean, '.local') || str_ends_with($clean, '.test') || str_ends_with($clean, '.localhost')) {
			return true;
		}

		return false;
	}

	// determine current environment mode (defaults to production if ambiguous)
	public static function current_env(): string {
		// 1. check wp-config constant override if explicitly declared
		if (defined('FINLYZER_ENV') && is_string(FINLYZER_ENV) && FINLYZER_ENV !== '') {
			return strtolower(trim(FINLYZER_ENV)) === self::ENV_DEVELOPMENT ? self::ENV_DEVELOPMENT : self::ENV_PRODUCTION;
		}

		// 2. check build-time baked constant
		if (defined('FINLYZER_BAKED_ENV') && is_string(FINLYZER_BAKED_ENV) && FINLYZER_BAKED_ENV !== '') {
			return strtolower(trim(FINLYZER_BAKED_ENV)) === self::ENV_DEVELOPMENT ? self::ENV_DEVELOPMENT : self::ENV_PRODUCTION;
		}

		// 3. check OS / web server environment variable
		$server_env = getenv('FINLYZER_ENV');
		if (is_string($server_env) && $server_env !== '') {
			return strtolower(trim($server_env)) === self::ENV_DEVELOPMENT ? self::ENV_DEVELOPMENT : self::ENV_PRODUCTION;
		}

		// 4. check WordPress standard environment type
		if (function_exists('wp_get_environment_type')) {
			$wp_env = wp_get_environment_type();
			if (in_array($wp_env, ['development', 'local'], true)) {
				return self::ENV_DEVELOPMENT;
			}
		}

		// 5. auto-detect local developer host (XAMPP, LocalWP, Docker on localhost)
		// unless explicitly marked as production, local hosts always operate in development mode
		if (self::is_local_host()) {
			return self::ENV_DEVELOPMENT;
		}

		// 6. check local .env.development file presence as fallback for local dev
		$dev_env_file = FINLYZER_PLUGIN_DIR . '.env.development';
		if (file_exists($dev_env_file) && !file_exists(FINLYZER_PLUGIN_DIR . '.env.production')) {
			return self::ENV_DEVELOPMENT;
		}

		return self::ENV_PRODUCTION;
	}

	// check if running in production mode
	public static function is_production(): bool {
		return self::current_env() === self::ENV_PRODUCTION;
	}

	// check if running in development mode
	public static function is_development(): bool {
		return self::current_env() === self::ENV_DEVELOPMENT;
	}

	// determine if developer diagnostic section should be rendered
	public static function dev_tools_enabled(): bool {
		// production builds strictly prohibit developer tools
		if (self::is_production()) {
			return false;
		}

		// check explicit constant override
		if (defined('FINLYZER_ENABLE_DEV_TOOLS')) {
			return (bool) FINLYZER_ENABLE_DEV_TOOLS;
		}

		// read from parsed development env file
		$val = self::read_env_value('FINLYZER_ENABLE_DEV_TOOLS');
		if ($val !== null) {
			return filter_var($val, FILTER_VALIDATE_BOOLEAN);
		}

		return true;
	}

	// check if debug logging is enabled
	public static function debug_logging(): bool {
		if (self::is_production()) {
			return false;
		}

		if (defined('FINLYZER_DEBUG_LOGGING')) {
			return (bool) FINLYZER_DEBUG_LOGGING;
		}

		$val = self::read_env_value('FINLYZER_DEBUG_LOGGING');
		if ($val !== null) {
			return filter_var($val, FILTER_VALIDATE_BOOLEAN);
		}

		return false;
	}

	// check if calculations MUST be routed through the serverless API (defaults to false for local-first execution)
	public static function force_api_calculation(): bool {
		if (defined('FINLYZER_FORCE_API_CALCULATION')) {
			return (bool) FINLYZER_FORCE_API_CALCULATION;
		}

		$val = self::read_env_value('FINLYZER_FORCE_API_CALCULATION');
		if ($val !== null) {
			return filter_var($val, FILTER_VALIDATE_BOOLEAN);
		}

		return false;
	}

	// check if strict SSL certificate validation is enforced
	public static function strict_ssl(): bool {
		if (self::is_production()) {
			return true;
		}

		if (defined('FINLYZER_STRICT_SSL')) {
			return (bool) FINLYZER_STRICT_SSL;
		}

		$val = self::read_env_value('FINLYZER_STRICT_SSL');
		if ($val !== null) {
			return filter_var($val, FILTER_VALIDATE_BOOLEAN);
		}

		return false;
	}

	// resolve API request timeout in seconds
	public static function api_timeout(): int {
		if (defined('FINLYZER_API_TIMEOUT')) {
			return max(3, min(30, (int) FINLYZER_API_TIMEOUT));
		}

		$val = self::read_env_value('FINLYZER_API_TIMEOUT');
		if ($val !== null && is_numeric($val)) {
			return max(3, min(30, (int) $val));
		}

		return self::is_production() ? 8 : 15;
	}

	// resolve Cloudflare Worker insight endpoint URL with security enforcement
	public static function worker_endpoint(): string {
		// 1. check wp-config modern constant
		if (defined('FINLYZER_WORKER_ENDPOINT') && is_string(FINLYZER_WORKER_ENDPOINT) && FINLYZER_WORKER_ENDPOINT !== '') {
			return (string) FINLYZER_WORKER_ENDPOINT;
		}

		// 2. check legacy constant fallback
		if (defined('FXLI_WORKER_ENDPOINT') && is_string(FXLI_WORKER_ENDPOINT) && FXLI_WORKER_ENDPOINT !== '') {
			return (string) FXLI_WORKER_ENDPOINT;
		}

		// 3. check build-time baked constant
		if (defined('FINLYZER_BAKED_WORKER_ENDPOINT') && is_string(FINLYZER_BAKED_WORKER_ENDPOINT) && FINLYZER_BAKED_WORKER_ENDPOINT !== '') {
			return (string) FINLYZER_BAKED_WORKER_ENDPOINT;
		}

		// 4. check database option
		if (function_exists('get_option')) {
			$opt = (string) get_option('finlyzer_worker_endpoint', '');
			if ($opt !== '') {
				return $opt;
			}
		}

		// 5. check active .env file
		$env_val = self::read_env_value('FINLYZER_WORKER_ENDPOINT');
		if ($env_val !== null && $env_val !== '') {
			return $env_val;
		}

		// 6. local development fallback for local loopback
		if (self::is_development()) {
			return 'http://127.0.0.1:8787/insight';
		}

		// 7. canonical production worker endpoint fallback
		return 'https://finlyzer-worker-prod.ebi1055lol.workers.dev/insight';
	}

	// resolve Cloudflare Worker order analysis endpoint URL with security enforcement
	public static function analyze_endpoint(): string {
		// 1. check direct analyze constant override
		if (defined('FINLYZER_WORKER_ANALYZE_ENDPOINT') && is_string(FINLYZER_WORKER_ANALYZE_ENDPOINT) && FINLYZER_WORKER_ANALYZE_ENDPOINT !== '') {
			return (string) FINLYZER_WORKER_ANALYZE_ENDPOINT;
		}

		// 2. check build-time baked constant
		if (defined('FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT') && is_string(FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT) && FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT !== '') {
			return (string) FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT;
		}

		// 3. check active .env file
		$env_val = self::read_env_value('FINLYZER_WORKER_ANALYZE_ENDPOINT');
		if ($env_val !== null && $env_val !== '') {
			return $env_val;
		}

		// 4. derive from worker_endpoint base
		$base = self::worker_endpoint();
		if ($base === '') {
			return '';
		}

		$clean_base = preg_replace('#(/api/v1)?/insight/?$#', '', rtrim($base, '/'));
		return $clean_base . '/api/v1/analyze';
	}

	// extract worker base URL origin (e.g. https://finlyzer-worker-prod.ebi1055lol.workers.dev)
	public static function worker_base_url(): string {
		$endpoint = self::worker_endpoint();
		if ($endpoint === '') {
			return '';
		}
		$clean = preg_replace('#(/api/v1)?/(insight|analyze|verify|benchmark|pair)/?$#', '', rtrim($endpoint, '/'));
		return $clean;
	}

	// check if administrator has explicitly opted into Finlyzer Cloud Sentinel service (Guidelines 7 & 9 compliant)
	public static function is_cloud_opted_in(): bool {
		if (function_exists('get_option')) {
			return get_option('finlyzer_cloud_opt_in', 'no') === 'yes';
		}
		return false;
	}

	// record administrator cloud opt-in choice
	public static function set_cloud_opt_in(bool $opt_in): bool {
		if (function_exists('update_option')) {
			return update_option('finlyzer_cloud_opt_in', $opt_in ? 'yes' : 'no', false);
		}
		return false;
	}

	// check if administrator has explicitly opted into live market exchange rates (Guideline 7 compliant)
	public static function is_live_rates_opted_in(): bool {
		if (class_exists('FXLI_Rate_Service')) {
			return FXLI_Rate_Service::is_live_rates_opted_in();
		}
		if (function_exists('get_option')) {
			return get_option('finlyzer_live_rates_opt_in', 'no') === 'yes';
		}
		return false;
	}

	// record administrator live market rates opt-in choice
	public static function set_live_rates_opt_in(bool $opt_in): bool {
		if (class_exists('FXLI_Rate_Service')) {
			return FXLI_Rate_Service::set_live_rates_opt_in($opt_in);
		}
		if (function_exists('update_option')) {
			return update_option('finlyzer_live_rates_opt_in', $opt_in ? 'yes' : 'no', false);
		}
		return false;
	}

	// retrieve HMAC secret across resolution hierarchy: constant -> env -> encrypted DB -> fallback
	public static function hmac_secret(): string {
		// 1. check wp-config constant override
		if (defined('FINLYZER_WORKER_HMAC_SECRET') && is_string(FINLYZER_WORKER_HMAC_SECRET) && FINLYZER_WORKER_HMAC_SECRET !== '') {
			return FINLYZER_WORKER_HMAC_SECRET;
		}

		// 2. check server environment variable
		$server_val = getenv('FINLYZER_WORKER_HMAC_SECRET');
		if (is_string($server_val) && $server_val !== '') {
			return $server_val;
		}

		// 3. check legacy constant override
		if (defined('FXLI_WORKER_HMAC_SECRET') && is_string(FXLI_WORKER_HMAC_SECRET) && FXLI_WORKER_HMAC_SECRET !== '') {
			return FXLI_WORKER_HMAC_SECRET;
		}

		// 4. check build-time baked constant
		if (defined('FINLYZER_BAKED_WORKER_HMAC_SECRET') && is_string(FINLYZER_BAKED_WORKER_HMAC_SECRET) && FINLYZER_BAKED_WORKER_HMAC_SECRET !== '') {
			return FINLYZER_BAKED_WORKER_HMAC_SECRET;
		}

		// 5. check authenticated encrypted database storage (2026 enterprise standard)
		if (class_exists('FXLI_Crypto')) {
			$stored = FXLI_Crypto::get_stored_secret();
			if (is_string($stored) && $stored !== '') {
				return $stored;
			}
		} elseif (function_exists('get_option')) {
			$opt = (string) get_option('finlyzer_worker_hmac_secret', '');
			if ($opt !== '') {
				return $opt;
			}
		}

		// 6. check active .env file
		$env_val = self::read_env_value('FINLYZER_WORKER_HMAC_SECRET');
		if ($env_val !== null && $env_val !== '') {
			return $env_val;
		}

		// 7. development fallback
		if (self::is_development()) {
			return 'dev-ephemeral-secret-32-byte-hex-token';
		}

		return '';
	}

	// identify active source of HMAC secret for administrator diagnostics
	public static function hmac_secret_source(): string {
		if (defined('FINLYZER_WORKER_HMAC_SECRET') && is_string(FINLYZER_WORKER_HMAC_SECRET) && FINLYZER_WORKER_HMAC_SECRET !== '') {
			return 'constant';
		}
		$server_val = getenv('FINLYZER_WORKER_HMAC_SECRET');
		if (is_string($server_val) && $server_val !== '') {
			return 'env';
		}
		if (defined('FXLI_WORKER_HMAC_SECRET') && is_string(FXLI_WORKER_HMAC_SECRET) && FXLI_WORKER_HMAC_SECRET !== '') {
			return 'constant';
		}
		if (defined('FINLYZER_BAKED_WORKER_HMAC_SECRET') && is_string(FINLYZER_BAKED_WORKER_HMAC_SECRET) && FINLYZER_BAKED_WORKER_HMAC_SECRET !== '') {
			return 'baked';
		}
		if (class_exists('FXLI_Crypto')) {
			$stored = FXLI_Crypto::get_stored_secret();
			if (is_string($stored) && $stored !== '') {
				return 'database';
			}
		} elseif (function_exists('get_option') && get_option('finlyzer_worker_hmac_secret', '') !== '') {
			return 'database';
		}
		$env_val = self::read_env_value('FINLYZER_WORKER_HMAC_SECRET');
		if ($env_val !== null && $env_val !== '') {
			return 'dotenv';
		}
		if (self::is_development()) {
			return 'dev_fallback';
		}
		return 'none';
	}

	// check if HMAC secret is locked by server-level configuration (constant or env)
	public static function is_hmac_secret_locked(): bool {
		$src = self::hmac_secret_source();
		return $src === 'constant' || $src === 'env' || $src === 'baked';
	}

	// retrieve masked version of active HMAC secret
	public static function get_masked_hmac_secret(): string {
		$secret = self::hmac_secret();
		if ($secret === '' || $secret === 'dev-ephemeral-secret-32-byte-hex-token') {
			return '';
		}
		return class_exists('FXLI_Crypto') ? FXLI_Crypto::mask_secret($secret) : substr($secret, 0, 4) . '••••••••' . substr($secret, -4);
	}

	// strictly validate endpoint URL against SSRF and protocol policies
	public static function validate_endpoint_url(string $url): bool|WP_Error {
		if ($url === '') {
			return new WP_Error('empty_endpoint', 'Worker endpoint URL is required.');
		}

		$parts = wp_parse_url($url);
		if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
			return new WP_Error('malformed_endpoint', 'Worker endpoint URL is malformed.');
		}

		$scheme = strtolower($parts['scheme']);
		$host = strtolower($parts['host']);

		// in production, strictly enforce HTTPS protocol
		if (self::is_production() && $scheme !== 'https') {
			return new WP_Error('insecure_protocol', 'Production API endpoints MUST use HTTPS encryption (TLS 1.2+).');
		}

		// SSRF defense: block loopback and private IP ranges in production
		if (self::is_production()) {
			// block explicit localhost name
			if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local')) {
				return new WP_Error('ssrf_blocked_host', 'Loopback hosts are prohibited in production mode.');
			}

			// resolve IP address
			$ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : gethostbyname($host);

			if (filter_var($ip, FILTER_VALIDATE_IP)) {
				// check private, reserved, and loopback ranges
				$flags = FILTER_FLAG_IPV4 | FILTER_FLAG_IPV6 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE;
				if (!filter_var($ip, FILTER_VALIDATE_IP, $flags)) {
					return new WP_Error('ssrf_blocked_ip', "Target IP {$ip} is within a prohibited private or loopback range.");
				}

				// check AWS metadata service (169.254.169.254)
				if ($ip === '169.254.169.254') {
					return new WP_Error('ssrf_blocked_metadata', 'Cloud metadata service access is strictly blocked.');
				}
			}
		}

		return true;
	}

	// read key from cached active .env file
	private static function read_env_value(string $key): ?string {
		if (self::$parsed_env_cache === null) {
			self::$parsed_env_cache = self::load_active_env_file();
		}

		return self::$parsed_env_cache[$key] ?? null;
	}

	// load active environment file according to determined mode
	private static function load_active_env_file(): array {
		$target_file = self::is_production()
			? FINLYZER_PLUGIN_DIR . '.env.production'
			: FINLYZER_PLUGIN_DIR . '.env.development';

		if (!file_exists($target_file)) {
			// fallback check for generic .env
			$generic = FINLYZER_PLUGIN_DIR . '.env';
			if (file_exists($generic)) {
				$target_file = $generic;
			} else {
				return [];
			}
		}

		$lines = file($target_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		if ($lines === false) {
			return [];
		}

		$env = [];
		foreach ($lines as $line) {
			$trimmed = trim($line);
			// skip comments
			if ($trimmed === '' || str_starts_with($trimmed, '#')) {
				continue;
			}

			$parts = explode('=', $trimmed, 2);
			if (count($parts) === 2) {
				$k = trim($parts[0]);
				$v = trim($parts[1]);
				// unquote if wrapped in quotes
				if ((str_starts_with($v, '"') && str_ends_with($v, '"')) || (str_starts_with($v, "'") && str_ends_with($v, "'"))) {
					$v = substr($v, 1, -1);
				}
				$env[$k] = $v;
			}
		}

		return $env;
	}
}


// -------------------------------------------------------------
// BUILD-TIME BAKED CONFIGURATION (PRODUCTION PROFILE)
// -------------------------------------------------------------
if (!defined('FINLYZER_BAKED_ENV')) {
	define('FINLYZER_BAKED_ENV', 'production');
}
if (!defined('FINLYZER_BAKED_WORKER_ENDPOINT')) {
	define('FINLYZER_BAKED_WORKER_ENDPOINT', 'https://finlyzer-worker-prod.ebi1055lol.workers.dev/insight');
}
if (!defined('FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT')) {
	define('FINLYZER_BAKED_WORKER_ANALYZE_ENDPOINT', 'https://finlyzer-worker-prod.ebi1055lol.workers.dev/api/v1/analyze');
}
if (!defined('FINLYZER_BAKED_WORKER_HMAC_SECRET') && '') {
	define('FINLYZER_BAKED_WORKER_HMAC_SECRET', '');
}
if (!defined('FINLYZER_ENABLE_DEV_TOOLS')) {
	define('FINLYZER_ENABLE_DEV_TOOLS', false);
}
if (!defined('FINLYZER_STRICT_SSL')) {
	define('FINLYZER_STRICT_SSL', true);
}
if (!defined('FINLYZER_FORCE_API_CALCULATION')) {
	define('FINLYZER_FORCE_API_CALCULATION', false);
}
